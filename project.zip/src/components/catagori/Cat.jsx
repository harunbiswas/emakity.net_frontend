import { useEffect, useState } from "react";
import cat from "../../assets/images/catagiri/cat-1.png";

export default function Cat({ data }) {
  const [title, setTitle] = useState("Vegetable");
  const [img, setImg] = useState(cat);

  useEffect(() => {
    if (data) {
      setTitle(data.name.en);
      if (data && data.media[1]) {
        setImg(data.media[1].url);
      }
    }
  }, [data]);

  // const noPhoto =
  //   "https://emakity.net/frontend/assets/img/product/category/category-home-1-img-1.jpg";
  return (
    <div className="cat-wrapper">
      <div className="cat">
        <img src={img} alt="catagori" />
        <strong className="cat-title">{title}</strong>
      </div>
    </div>
  );
}
