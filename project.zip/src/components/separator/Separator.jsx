export default function Separator() {
  return <div className="separator"></div>;
}
