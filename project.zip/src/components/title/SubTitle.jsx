export default function SubTitle({ name }) {
  return <h4 className="sub-title">{name}</h4>;
}
