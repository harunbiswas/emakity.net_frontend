import { BsFillPhoneVibrateFill } from "react-icons/bs";
import { GoLocation } from "react-icons/go";
import { MdLanguage } from "react-icons/md";
import useLogo from "../../assets/images/header/usa-logo.png";

export default function TopHeader() {
  return (
    <div className="top-header ">
      <div className="container">
        <div className="top-header-wrapper">
          <div className="top-header-left">
            <div className="top-header-item">
              <div className="icon ">
                <GoLocation size={28} />
              </div>
              <p className="text">1326 Central Ave Queens, NY</p>
            </div>
            <div className="top-header-item">
              <div className="icon ">
                <BsFillPhoneVibrateFill size={28} />
              </div>
              <p className="text">1326 Central Ave Queens, NY</p>
            </div>
          </div>
          <div className="top-header-right ">
            <div className="top-header-item">
              <div className="image">
                <img className="" src={useLogo} alt="Unaited state" />
              </div>
              <select name="country" id="">
                <option value="1" className="text ">
                  United States
                </option>
                <option value="1" className="text ">
                  United States
                </option>
                <option value="1" className="text ">
                  United States
                </option>
                <option value="1" className="text ">
                  United States
                </option>
              </select>
            </div>
            <div className="top-header-item">
              <div className="icon ">
                <MdLanguage size={28} />
              </div>
              <select name="languase" id="">
                <option value="1" className="text ">
                  English
                </option>
                <option value="1" className="text ">
                  English
                </option>
                <option value="1" className="text ">
                  English
                </option>
                <option value="1" className="text ">
                  English
                </option>
              </select>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
