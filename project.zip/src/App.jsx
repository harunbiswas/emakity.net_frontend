import axios from "axios";
import { useEffect, useState } from "react";
import { HashRouter } from "react-router-dom";
import "./App.css";
import preloder from "./assets/images/preloder.gif";
import { ThemeContext } from "./components/context/ThemeContext";
import TopHeader from "./components/header/TopHeader";
import Routers from "./router/Routers";
import Footer from "./section/footer/Footer";
import Values from "./Values";

function App() {
  const [data, setData] = useState({});
  const [loading, setLoading] = useState(true);

  const homeURL = `${Values.BASE_URL}home`;

  useEffect(() => {
    axios
      .get(homeURL, {
        headers: {
          "Api-Access-Token":
            "743b1e57df96fc47abd528c7f2b34242edd81c23dbe252928954b8ddc169ca27",
          "Content-Type": "application/json",
        },
      })
      .then((d) => {
        setData(d.data.data);
        console.log(d.data.data);
        setLoading(false);
      })
      .catch((e) => {
        alert(e.response.data.message);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="loading-img-wrapper">
        <img className="loading-img" src={preloder} alt="" />;
      </div>
    );
  } else {
    return (
      <div className="App">
        <HashRouter>
          <TopHeader />
          <main>
            <ThemeContext.Provider value={data}>
              <Routers />
            </ThemeContext.Provider>
          </main>
          <Footer />
        </HashRouter>
      </div>
    );
  }
}

export default App;
