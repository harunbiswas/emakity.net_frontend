// http://emakity.shop/api/v1/home
// https://emakity.shop/api/v1/market/{id}
// https://emakity.shop/api/v1/category/{id}"

// https://cpanel.mandenko.com/
// username: mandenko
// PW: Bravo2022!

const Values = {
  BASE_URL: "https://emakity.shop/api/v1/",
};

export default Values;
