import axios from "axios";
import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import preloder from "../assets/images/preloder.gif";
import BottomHeader from "../components/header/BottomHeader";
import Separator from "../components/separator/Separator";
import StoreDetails from "../components/store/StoreDetails";
import Baner from "../section/baner/Baner";
import Catagori from "../section/catagori/Catagori";
import AllProduct from "../section/Product/AllProduct";
import WeekProduct from "../section/Product/WeekProduct";
import Values from "../Values";

export default function Store() {
  const [catagori, setCatagori] = useState([]);
  const [products, setProducts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [storeData, setStoreData] = useState("");

  const param = useParams();
  const storeURL = `${Values.BASE_URL}market/${param.id}`;

  useEffect(() => {
    axios
      .get(storeURL, {
        headers: {
          "Api-Access-Token":
            "743b1e57df96fc47abd528c7f2b34242edd81c23dbe252928954b8ddc169ca27",
          "Content-Type": "application/json",
        },
      })
      .then((d) => {
        //setData(d.data.data);
        setCatagori(d.data.data.categories);
        setProducts(d.data.data.data.products);
        setStoreData(d.data.data.data);
        setIsLoading(false);
      })
      .catch((e) => {
        alert(e.response.data.message);
        setIsLoading(false);
      });
  }, []);

  if (isLoading) {
    return (
      <div className="loading-img-wrapper">
        <img className="loading-img" src={preloder} alt="" />;
      </div>
    );
  } else {
    return (
      <div id="store">
        <BottomHeader />
        <Baner />
        <StoreDetails storeData={storeData} />
        <Catagori catagori={catagori} />
        <Separator />
        <WeekProduct data={products} />
        <Separator />
        <AllProduct products={products} />
      </div>
    );
  }
}
