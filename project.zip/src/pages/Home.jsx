import { useContext, useEffect, useState } from "react";
import { ThemeContext } from "../components/context/ThemeContext";
import BottomHeader from "../components/header/BottomHeader";
import MiddleHeader from "../components/header/MidleHeader";
import Separator from "../components/separator/Separator";
import Title from "../components/title/Title";
import Baner from "../section/baner/Baner";
import Catagori from "../section/catagori/Catagori";
import FeaturedProduct from "../section/Product/FeaturedProduct";
import WeekProduct from "../section/Product/WeekProduct";

export default function Home() {
  const [catagori, setCatagori] = useState([]);
  const [featurdMarkets, setFeaturdMarkets] = useState([]);
  const context = useContext(ThemeContext);

  useEffect(() => {
    if (context && context.categories) {
      setCatagori(context.categories);
    }
    if (context && context.featured_markets) {
      setFeaturdMarkets(context.featured_markets);
    }
    //console.log(context);
  }, [context]);

  return (
    <div id="home">
      <MiddleHeader />
      <BottomHeader />
      <Baner />
      <Catagori catagori={catagori} />
      <WeekProduct />
      <div className="home-product-wrapper">
        <Title name="Find Our Featured & Top Markets" />
        {featurdMarkets.map((data, i) => (
          <div key={i}>
            <FeaturedProduct data={data} />
            <Separator />
          </div>
        ))}
      </div>
      <WeekProduct />
    </div>
  );
}
