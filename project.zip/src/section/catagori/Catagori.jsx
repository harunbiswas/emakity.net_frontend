import { useEffect, useState } from "react";
import Slider from "react-slick";
import Cat from "../../components/catagori/Cat";
import Title from "../../components/title/Title";

export default function Catagori({ catagori }) {
  const [catData, setCatData] = useState([]);

  useEffect(() => {
    setCatData(catagori);
  }, [catagori]);
  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 5,
    slidesToScroll: 1,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 4,
        },
      },
      {
        breakpoint: 768,
        settings: {
          slidesToShow: 3,
        },
      },
      {
        breakpoint: 480,
        settings: {
          slidesToShow: 1,
        },
      },
    ],
  };
  return (
    <section id="catagori">
      <div className="container">
        <Title name="Choose among our List of Product Categories" />
        <Slider {...settings}>
          {catData.map((data, i) => (
            <Cat key={i} data={data} />
          ))}
        </Slider>
      </div>
    </section>
  );
}
