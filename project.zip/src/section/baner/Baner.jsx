import { AiFillMessage } from "react-icons/ai";
import { MdMyLocation } from "react-icons/md";
import NavMenu from "../../components/nav/NavMenu";
import Search from "../../components/search/Search";
import BanerSlider from "../../components/slider/BanerSlider";

export default function Baner() {
  return (
    <div id="baner">
      <NavMenu />

      <div className="container">
        <BanerSlider />
        <Search />
        <div className="baner-btn-body">
          <div className="container">
            <div className="baner-btn-wrapper">
              <a className="btn btn-white baner-btn" href="/">
                {" "}
                <MdMyLocation />
              </a>
              <a className="btn btn-white baner-btn" href="/">
                {" "}
                <AiFillMessage />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
