import { useEffect, useState } from "react";
import Product from "../../components/product/Product";
import Title from "../../components/title/Title";

export default function AllProduct({ products }) {
  const [product, setProcut] = useState([]);

  useEffect(() => {
    setProcut(products);
  });
  return (
    <section id="all-product">
      <div className="container">
        <Title name="See All Products at Family Saving Grocery" />
        <div className="all-product-wrapper">
          {product.map((data, i) => (
            <Product key={i} product={data} />
          ))}
        </div>
      </div>
    </section>
  );
}
