export default function Title({ name }) {
  return <h2 className="title">{name}</h2>;
}
