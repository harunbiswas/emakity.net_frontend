import ProductModal from "../components/product/ProductModal";

export default function SingleProduct() {
  return (
    <div className="single-product">
      <ProductModal />
    </div>
  );
}
